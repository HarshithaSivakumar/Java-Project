
/**
 *Some partially help for some error for the giveInformation() method from the TA 
 *
 * @author Harshitha Sivakumar and Sanaa Cheikh
 * @version 24 Jan 2025
 * 
 */
import java.util.*;
public class Course
{ 
    // instance variables 
    private String courseCode;
    private String profName;
    private int maxNumber;
    private List<Student>registeredStudentList;
    
    /**
     * Constructor for objects of class Course
     */
    public Course(String thecourseCode,int maxCapacity )
    {
        // initialise instance variables
        courseCode=thecourseCode;
        maxNumber=maxCapacity;
        profName="TBA";
        registeredStudentList = new ArrayList<Student>();
    }

    //Setting the professor's name
    public void setProf(String name)
    {
        profName = name;
    }
    //gets the course code
    public String getCourseCode() {
        return courseCode;
    }
    
    /**
     * Adding student object to list of students
     */
    public boolean addStudent(Student student) {
        if (registeredStudentList.size() < maxNumber) {
            registeredStudentList.add(student); // Add the student's name to the list
            //System.out.println("Student Name is added to the list");  testing purpose
            return true;
        }else {
            //System.out.println("No name is added to the list");testing purpose
            return false;
        }
    }
    
    /**
     * Print the information
     */
    public void giveInformation(){
        System.out.println("The course code: "+ courseCode);
        System.out.println("Professor: "+ profName);
        System.out.println(registeredStudentList);
        //System.out.println(Student.getInformation()); testing purpose
        for (int i = 0; i < registeredStudentList.size(); i++) {
            Student student = registeredStudentList.get(i); // Access the student object at index i
            student.getInformation(); // Call the getInformation() method for the student
        }       
    }
} 
