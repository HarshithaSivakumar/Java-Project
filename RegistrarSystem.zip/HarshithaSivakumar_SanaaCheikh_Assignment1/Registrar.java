import java.util.*;

/**
 *All the coding are done by us.
 *
 * @author Sanaa Cheikh and Harshitha Sivakumar
 * @version 25 Jan 2025
 */
public class Registrar
{
    // instance variables creating list for each classes
    private List<Student>studentList;
    private List<Course>courseList;
    
    /**
     * Constructor for objects of class Registrar
     */
    public Registrar()
    {
        // initialise instance variable
        studentList = new ArrayList<Student>();//empty list
        courseList = new ArrayList<Course>();//empty list
    }

    //Adds the course to the list
    public void addCourse(Course course){
        courseList.add(course);
    }
    
    //Adds the student to the list
    public void addStudent(Student student){
        studentList.add(student);
    }
    
    /*
     * Assigns a professor to a course based on the course code. 
     *If the course is found, the professor is set for that course, and a confirmation message is printed. 
     * If the course is not found, an error message is displayed.
     */
    public void setProfessorName(String professorName,String courseCode){
        for (int i = 0; i < courseList.size(); i++) {
            if (courseList.get(i).getCourseCode().equals(courseCode)) {
                courseList.get(i).setProf(professorName);
                System.out.println("Professor " + professorName + " is givenn to course " + courseCode);
                return;
            }
        }
        System.out.println("Course with code " + courseCode + " not found.");
    }
    
    
    public void addStudentInCourse(String name, String code)   {
        for(int i=0;i<courseList.size();i++){//goes through the list of courses 
            Course course = courseList.get(i);//object of class course as an element of courseList
            if(course.getCourseCode().equals(code)){// checks if course corresponding to the given 
                //code exists in the list, if it does then it will check if the student of the given name exists through loop below.
                for(int j=0;j<studentList.size();j++){ //goes through list of students 
                    Student student = studentList.get(j);//object of class student belonging to list studentList
                    if(student.getStudentName().equals(name)){// checks if the student of the given nam exists 
                        if (course.addStudent(student)){ //if the student exists in the list it will check whether or 
                            // not the student has been added depending on the course's max capacity 
                          System.out.println("The Student is added to the course");
                        }
                        else{
                            System.out.println("course at capacity");
                        }
                        
                    }else{
                        System.out.println("name not found");
                    }
                }
            }else{
                System.out.println("course doesn't exist");//exists the main loop if course doesn't exist
            }
    
        }
    }
    //the simliar logic followed but instead of using the given name, the given studentID is being checked 
    public void addStudentInCourse2(String studentID, String code)   {
        for(int i=0;i<courseList.size();i++){
            Course course = courseList.get(i);
            if(course.getCourseCode().equals(code)){
                
                for(int j=0;j<studentList.size();j++){
                    Student student = studentList.get(j);
                    if(student.getStudentID().equals(studentID)){
                       // int index2 = studentList.indexOf(j)
                        if (course.addStudent(student)){
                          System.out.println("The Student is added to the course");
                        }
                        else{
                            System.out.println("course at capacity");
                        }
                        
                    }else{
                        System.out.println("ID not found");
                    }
                }
            }else{
                System.out.println("course doesn't exist");
            }
    
        }
    }
    
}


