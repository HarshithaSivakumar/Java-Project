
/**
 * Write a description of class Student here.
 *
 * @author Harshitha Sivakumar and Sanaa Cheikh
 * @version 23 Jan 2025
 * All coding are done by us not AI is used here
 */
public class Student
{
    // instance variables 
    private String name;
    private String idNumber;
    private int courseCredits;
    private int courseCompleted;

    /**
     * Constructor for objects of class Student
     */
    public Student(String aName,String anIdnumber)
    {
        // initialise instance variables
        name = aName;
        idNumber = anIdnumber;
        courseCredits = 0;
        courseCompleted = 0;
    }

    //Adds the credits to the student's total course credits.
    public void setcourseCredits(int addCredits)
    {
        courseCredits = courseCredits + addCredits;
    }
    
    //adds the course completed to the student's total
    public void setcourseCompleted(int addCompletedCourse)
    {
        courseCompleted = courseCompleted + addCompletedCourse;
    }
    //gets student name
    public String getStudentName(){
        return name;
    }
    //get student's id
    public String getStudentID(){
        return idNumber;
    }
    //calculates the gpa
    public double getGpa(){
    if (courseCompleted == 0){
        System.out.println("Error");
        return 0;
    }
    else{
        return courseCredits/courseCompleted;
    }
    }
    //gives information on student name ,ID, GPA
    public void getInformation(){
        System.out.println("Student Name" + name);
        System.out.println("ID#" + idNumber);
        System.out.println("GPA " + getGpa());
    }
}
